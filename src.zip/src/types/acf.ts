export type AcfHero = {
  hero_heading: string;
  hero_text: string;
};
