"use client";

import { useEffect, useRef } from "react";
import React from "react";
import style from "@/compornent/Skills.module.scss";
import SkillsItem from "./Skills/SkillsItem";

type SkillsProps = {
  skills: {
    heading: string;
  };
};

const Skills = ({ skills }: SkillsProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // refから対象のDOM要素（横スクロールさせたい要素）を取得
    const el = scrollRef.current;
    //DOMが取得できなければ何もせず終了(null安全チェック)
    if (!el) return;
    //ホイールイベント(マウススクロール)を処理する関数
    const handlewheel = (e: WheelEvent) => {
      //対象要素をビューポート内での位置を取得
      const rect = el.getBoulingClientRect();
      // 対象要素が現在画面内に「見えているか」を判定
      // 条件：要素の上端が画面上に達していて、下端がまだ画面内にある
      const inView = rect.top <= 0 && rect.buttom > window.innerHeight;
      if (inView) {
        // 縦スクロールを止める（通常のスクロールを無効化）
        e.preventDefault();
        // スクロール量（deltaY）を横方向に適用して、横スクロールさせる
        el.scrollLeft += e.deltaY;
      }
    };

    //windowに対してwheelイベントの登録(passive: falseでpreventDefaultが効くように)
    window.addEventListener("wheel", handlewheel, { passive: false });

    //クリーンアップ処理：コンポーネントがアンマウントされるときにイベント削除
    return () => {
      window.removeEventListener("wheel", handleWheel);
    };
  }, []); // 空の依存配列なので、初回マウント時に1回だけ実行される

  return (
    <div className={style.Skill}>
      <h2>{skills.heading}</h2>
      <div
        className={style.Skill_Slider}
        ref={scrollRef}
        style={{
          overflowX: "auto",
          overflowY: "hidden",
          whiteSpace: "nowrap",
          display: "flex",
        }}
      >
        <SkillsItem />
      </div>
    </div>
  );
};

export default Skills;
