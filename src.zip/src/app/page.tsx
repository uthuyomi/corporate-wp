import Index from "@/page/index";

export default function Home() {
  return (
    <Index />
  );
}
