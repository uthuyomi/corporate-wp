import React from 'react';
import Hero from "@/compornent/Hero"
import Service from '@/compornent/Service';
import Skills from '@/compornent/Skills';
import Contact from '@/compornent/Contact';
import Profile from '@/compornent/Profile';
import Data from '@/data/data.json'

export async function getStaticProps() {
  const res = await fetch(
    "https://webyayasu.sakura.ne.jp/webyayasu-next/wp-json/wp/v2/pages/21?acf_format=standard"
  );

  console.log("ステータスコード:", res.status);

  const page = await res.json();
  console.log("ページデータ:", page.acf.hero_heading);
  console.log("取得した生データ:", page);

  return { props: { page } };
}

type PageProps = {
    acf: {
      hero_heading?: string;
      hero_text?: string;
    };
};

const index = ({ page }: PageProps) => {
  console.log("ページデータ:", page.acf.hero_heading);
  console.log("取得したページデータ:", page);
  return (
    <>
      {(page?.acf?.hero_heading || page?.acf?.hero_text) && (
        <Hero hero={Data.toppage.hero} acf={page.acf} />
      )}
      <Profile profile={Data.toppage.profile} />
      <Service service={Data.toppage.service} />
      <Skills skills={Data.toppage.skills} />
      <Contact contact={Data.toppage.contact} />
    </>
  );
}

export default index;